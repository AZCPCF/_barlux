const lessons = ['raizi','fizik','shimi']
for (let index = 0; index < 3; index++) {
    let random = Math.floor(Math.random() * lessons.length )
    console.log(lessons[random]);
    lessons.splice(random,1)
    
}