import React from "react";
import Home from "./Home";
import {
  Box,
  Button,
  Grid,
  Input,
  TextField,
  Typography,
  useMediaQuery,
} from "@mui/material";
import InstagramIcon from "@mui/icons-material/Instagram";
import PhoneIcon from "@mui/icons-material/Phone";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import {
  AboutCard,
  AboutCardIconParent,
  AboutCardTextParent,
  ContactUsIcon,
  Line,
} from "../Styles/ContactUsStyle";
import json from "../JSON/variables.json";
import EmailIcon from "@mui/icons-material/Email";
import { useTheme } from "@emotion/react";
const ContactUs = () => {
  const theme = useTheme();

  const lg = useMediaQuery(theme.breakpoints.up("lg"));
  const sm = useMediaQuery(theme.breakpoints.up("sm"));
  return (
    <Home>
      <Box flexGrow={"1"}>
        <Grid
          container
          direction="row"
          mt={"150px"}
          mb={"100px"}
          justifyContent="space-evenly"
          alignproducts="center"
          height={"70vh"}
          xs={12}
        >
          <Grid
            lg={8}
            xs={10}
            height={"100%"}
            border={"1px solid #D9D9D9"}
            borderRadius={"16px"}
            position={"relative"}
            container
            justifyContent={"center"}
            padding={lg ? "100px" : "10px"}
            paddingTop={lg ? "100px" : "60px"}
          >
            <ContactUsIcon>
              <EmailIcon sx={{ fontSize: lg ? "64px" : "48px" }} />
            </ContactUsIcon>
            <Grid
              xs={12}
              height={"20px"}
              container
              justifyContent={"space-between"}
              textAlign={"center"}
              alignItems={"center"}
              mb={'50px'}
            >
              <Line />

              <Typography
                variant={lg ? "h4":'h5'}
                color={json.color.default}
                width={"20%"}
              >
                ارتباط با ما
              </Typography>
              <Line />
            </Grid>
            <Grid xs={12}>
              <form>
                <Grid
                  xs={12}
                  container
                  justifyContent={"space-between"}
                  m={"20px 0"}
                >
                  <Grid lg={5.5} xs={12} mb={!lg ? "10px" : "24px"}>
                    <TextField
                      sx={{ width: "100%" }}
                      variant="outlined"
                      label="نام و نام خانوادگی"
                    />
                  </Grid>
                  <Grid lg={5.5} xs={12}>
                    <TextField
                      sx={{ width: "100%" }}
                      variant="outlined"
                      label="شماره تماس"
                    />
                  </Grid>
                </Grid>
                <Grid lg={12} m={"20px 0"}>
                  <TextField
                    sx={{ width: "100%" }}
                    variant="outlined"
                    label="ایمیل"
                  />
                </Grid>
                <Grid lg={12} height={"200px"}>
                  <TextField
                    sx={{ width: "100%" }}
                    id="outlined-multiline-static"
                    multiline
                    label="پیام"
                    rows={5}
                    variant="outlined"
                  />
                </Grid>
                <Grid lg={2}>
                  <Button
                    variant="contained"
                    sx={{
                      color: json.color.white_1,
                      width: "100%",
                      height: "50px",
                      fontSize: "1rem",
                    }}
                  >
                    ارسال پیام
                  </Button>
                </Grid>
              </form>
            </Grid>
          </Grid>
          <Grid
            lg={2}
            xs={10}
            height={"70vh"}
            container
            alignContent={"space-between"}
            mt={lg ? "0px" : "100px"}
          >
            <Grid
              xs={12}
              border={"1px solid #D9D9D9"}
              borderRadius={"16px"}
              position={"relative"}
              container
              justifyContent={"center"}
              height={"20%"}
            >
              <AboutCard>
                <AboutCardIconParent>
                  <InstagramIcon className="icon-rwdijad" />
                </AboutCardIconParent>
                <AboutCardTextParent>
                  <Typography variant={"h6"} sx={{ color: "#727272" }}>
                    اینستاگرام:
                  </Typography>
                  <Typography
                    variant={lg ? "" : "caption"}
                    sx={{ color: "#4F4F4F", pt: "5px" }}
                  >
                    @Barlux_social.media
                  </Typography>
                </AboutCardTextParent>
              </AboutCard>
            </Grid>
            <Grid
              xs={12}
              border={"1px solid #D9D9D9"}
              borderRadius={"16px"}
              position={"relative"}
              container
              justifyContent={"center"}
              height={"20%"}
            >
              <AboutCard>
                <AboutCardIconParent>
                  <EmailIcon className="icon-rwdijad" />
                </AboutCardIconParent>
                <AboutCardTextParent>
                  <Typography variant={"h6"} sx={{ color: "#727272" }}>
                    ایمیل:
                  </Typography>
                  <Typography
                    variant={lg ? "" : "caption"}
                    sx={{ color: "#4F4F4F", pt: "5px" }}
                  >
                    testmail@test.com
                  </Typography>
                </AboutCardTextParent>
              </AboutCard>
            </Grid>
            <Grid
              xs={12}
              border={"1px solid #D9D9D9"}
              borderRadius={"16px"}
              position={"relative"}
              container
              justifyContent={"center"}
              height={"20%"}
            >
              <AboutCard>
                <AboutCardIconParent>
                  <PhoneIcon className="icon-rwdijad" />
                </AboutCardIconParent>
                <AboutCardTextParent>
                  <Typography variant={"h6"} sx={{ color: "#727272" }}>
                    تلفن:
                  </Typography>
                  <Typography
                    variant={lg ? "" : "caption"}
                    sx={{ color: "#4F4F4F", pt: "5px" }}
                  >
                    09050493004
                  </Typography>
                </AboutCardTextParent>
              </AboutCard>
            </Grid>
            <Grid
              xs={12}
              border={"1px solid #D9D9D9"}
              borderRadius={"16px"}
              position={"relative"}
              container
              justifyContent={"center"}
              height={"20%"}
            >
              <AboutCard>
                <AboutCardIconParent>
                  <LocationOnIcon className="icon-rwdijad" />
                </AboutCardIconParent>
                <AboutCardTextParent>
                  <Typography variant={"h6"} sx={{ color: "#727272" }}>
                    آدرس:
                  </Typography>
                  <Typography
                    variant={lg ? "" : "caption"}
                    sx={{ color: "#4F4F4F", pt: "5px" }}
                  >
                    قائمشهر خیابان بابل 
                  </Typography>
                </AboutCardTextParent>
              </AboutCard>
            </Grid>
            {/* <Grid
            xs={12}
            border={"1px solid #D9D9D9"}
            borderRadius={"16px"}
            position={"relative"}
            container
            justifyContent={"center"}
            height={'20%'}
          >salam
            </Grid> */}
            {/* <Grid
            xs={12}
            border={"1px solid #D9D9D9"}
            borderRadius={"16px"}
            position={"relative"}
            container
            justifyContent={"center"}
            height={'20%'}
          >salam
            </Grid> */}
            {/* <Grid
            xs={12}
            border={"1px solid #D9D9D9"}
            borderRadius={"16px"}
            position={"relative"}
            container
            justifyContent={"center"}
            height={'20%'}
          >salam
            </Grid> */}
          </Grid>
        </Grid>
      </Box>
    </Home>
  );
};

export default ContactUs;
