import React, { useContext } from "react";
import Home from "./Home";
import Banner from "../Components/Banner";
import ProductCM from "../Components/ProductCM";
import { ResponsiveContext } from "../Components/ResponsiveContext";

const Index = () => {
  const all = useContext(ResponsiveContext);
  console.log(all);
  return (
    <>
    </>
    // <Home>
    //   <Banner count={1} xs={10} height={60} mt={100} mb={50} />
    //   <ProductCM category_id={22} title={"پرفروش ترین ها"} />
    //   <Banner count={1} xs={10} height={20} mt={25} mb={25} />
    //   <ProductCM title={"پرتکرار ترین ها"} />
    //   <Banner count={3} lg={2.5} xs={10} height={20} mt={25} mb={25} />
    //   <ProductCM title={"انواع محصولات"} />
    // </Home>
  );
};

export default Index;
