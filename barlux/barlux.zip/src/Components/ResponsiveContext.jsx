// TokenContext.js
import { useMediaQuery, useTheme } from "@mui/material";
import React, { createContext, useEffect, useState } from "react";

const ResponsiveContext = createContext();

const ResponsiveProvider = ({ children }) => {
  const theme = useTheme();
  const xl = useMediaQuery(theme.breakpoints.up('xl'))
  const lg = useMediaQuery(theme.breakpoints.up('lg'))
  const md = useMediaQuery(theme.breakpoints.up('md'))
  const sm = useMediaQuery(theme.breakpoints.up('sm'))
  const xs = useMediaQuery(theme.breakpoints.up('xs'))
  return (
    <ResponsiveContext.Provider value={{ xl,lg,md,sm,xs }}>
      {children}
    </ResponsiveContext.Provider>
  );
};

export { ResponsiveProvider, ResponsiveContext };
