import React, { useContext, useEffect, useState } from "react";
import { TokenContext } from "../Components/TokenContext";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Header from "../Components/Header";
import Home from "../Pages/Home";
import Footer from "../Components/Footer";
import Banner from "../Components/Banner";
import NotFound from "../Components/NotFound";
import ProductCM from "../Components/ProductCM";
import Loading from "../Components/Loading";
import { useTheme } from "@emotion/react";
import Index from "../Pages/Index";
import ContactUs from "../Pages/ContactUs";
export default function AppRoutes() {
  const { token } = React.useContext(TokenContext);
  const [tokenn, setTokenn] = useState(token);
  const [loadings, setLoadings] = useState([]);
  const theme = useTheme();
  console.log(theme.breakpoints.up("lg"));
  const [loading, setLoading] = useState(false);
  console.log(tokenn);
  useEffect(() => {
    setTokenn(token);
  }, [token]);
  return (
    <BrowserRouter>
      {/* {tokenn == null ? (
        <Routes>
          <Route path="/" element={<p>s</p>} />
          <Route path="/footer" element={<Footer />} />
        </Routes>
      ) : ( */}
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/contactus" element={<ContactUs />} />
        <Route path="/aboutus" element={<ContactUs />} />
        <Route path="/products" element={<ContactUs />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      {/* )} */}
    </BrowserRouter>
  );
}
